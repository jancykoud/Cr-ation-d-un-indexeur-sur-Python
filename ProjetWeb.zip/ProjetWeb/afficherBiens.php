<?php
include 'connexion.php';

$sql = "SELECT * FROM Biens";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Affichage de chaque bien
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["idBien"]. " - Propriétaire: " . $row["mailProprio"]. " - Commune: " . $row["commune"]. " - Rue: " . $row["rue"]. " - CP: " . $row["cp"]. " - Couchages: " . $row["nbCouchages"]. " - Chambres: " . $row["nbChambres"]. " - Distance: " . $row["distance"]. " - Prix: " . $row["prix"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
