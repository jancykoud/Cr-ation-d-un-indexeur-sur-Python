CREATE TABLE Utilisateurs (
    mail VARCHAR(255) PRIMARY KEY,
    prenom VARCHAR(50),
    nom VARCHAR(50),
    telephone VARCHAR(15)
);

INSERT INTO Utilisateurs (mail, prenom, nom, telephone) VALUES
('user1@example.com', 'Faure', 'MOUANDA', '0123456789'),
('user2@example.com', 'Kwenneth', 'KIKHOUNGA', '0123456798'),
('user3@example.com', 'Hardy', 'NGOUALA', '0123456879'),
('user4@example.com', 'Roger', 'BAVIBIDILA', '0123456978'),
('user5@example.com', 'Alix', 'YOUMA', '0123465789'),
('user6@example.com', 'Obede', 'MPASSY', '0123567890'),
('user7@example.com', 'Gina', 'Leroy', '0123678901'),
('user8@example.com', 'Hugo', 'Moreau', '0123789012'),
('user9@example.com', 'Iris', 'Fournier', '0123890123'),
('user10@example.com', 'Julien', 'Girard', '0123901234');
