<?php
$servername = "localhost"; // ou l'adresse de votre serveur MySQL
$username = "jancy.koud-banga@etu.umontpellier.fr"; // votre nom d'utilisateur MySQL
$password = "1996Banga"; // votre mot de passe MySQL
$dbname = "e20230004133"; // le nom de votre base de données

// Création de la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
