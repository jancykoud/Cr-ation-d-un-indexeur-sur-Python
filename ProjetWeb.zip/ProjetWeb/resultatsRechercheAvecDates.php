<?php
include 'connexion.php';

// Récupération des autres critères de recherche
$dateDebut = $_GET['dateDebut'];
$dateFin = $_GET['dateFin'];

// Requête SQL pour sélectionner les biens disponibles
$sql = "SELECT * FROM Biens WHERE idBien NOT IN (
    SELECT idBien FROM Locations WHERE (dateDebut <= '$dateFin' AND dateFin >= '$dateDebut')
) AND /* vos autres conditions ici */";

$result = $conn->query($sql);

// Affichage des résultats
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["idBien"]. " - Commune: " . $row["commune"]. " - Prix: " . $row["prix"]. " - Couchages: " . $row["nbCouchages"]. " - Chambres: " . $row["nbChambres"]. " - Distance: " . $row["distance"];
        echo " <a href='detailBien.php?idBien=".$row["idBien"]."'>Voir Détails</a><br>";
    }
        // Afficher les détails des biens ici
    }
else {
    echo "Aucun bien disponible trouvé pour les dates sélectionnées.";
}
$conn->close();
?>
