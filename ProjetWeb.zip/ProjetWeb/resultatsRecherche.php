<?php
include 'connexion.php';

$commune = $_GET['commune'];
$prixMax = $_GET['prixMax'];
$nbCouchagesMin = $_GET['nbCouchagesMin'];
$nbChambresMin = $_GET['nbChambresMin'];
$distanceMax = $_GET['distanceMax'];

$sql = "SELECT * FROM Biens WHERE (commune LIKE '%$commune%') AND (prix <= $prixMax OR $prixMax IS NULL) AND (nbCouchages >= $nbCouchagesMin OR $nbCouchagesMin IS NULL) AND (nbChambres >= $nbChambresMin OR $nbChambresMin IS NULL) AND (distance <= $distanceMax OR $distanceMax IS NULL)";

$result = $conn->query($sql);

// Affichage des résultats
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["idBien"]. " - Commune: " . $row["commune"]. " - Prix: " . $row["prix"]. " - Couchages: " . $row["nbCouchages"]. " - Chambres: " . $row["nbChambres"]. " - Distance: " . $row["distance"]. "<br>";
    }
} else {
    echo "Aucun bien trouvé.";
}
$conn->close();
?>
