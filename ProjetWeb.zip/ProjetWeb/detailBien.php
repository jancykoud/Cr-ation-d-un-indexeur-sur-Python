<?php
include 'connexion.php';

$idBien = $_GET['idBien'];

$sql = "SELECT * FROM Biens WHERE idBien = $idBien";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Affichez ici les détails du bien
    echo "Commune: " . $row["commune"]. " - Prix: " . $row["prix"]. " - Couchages: " . $row["nbCouchages"]. " - Chambres: " . $row["nbChambres"]. " - Distance: " . $row["distance"];
    // Ajoutez ici un formulaire ou un lien pour la réservation
} else {
    echo "Bien non trouvé.";
}
$conn->close();
?>
<form action="submitRating.php" method="post">
    <input type="hidden" name="idBien" value="<?php echo $idBien; ?>">
    Note: 
    <select name="rating">
        <option value="1">1 Étoile</option>
        <option value="2">2 Étoiles</option>
        <option value="3">3 Étoiles</option>
        <option value="4">4 Étoiles</option>
        <option value="5">5 Étoiles</option>
    </select>
    <input type="submit" value="Soumettre">

</form>
<?php
    $sql = "SELECT AVG(note) as moyenne FROM Avis WHERE idBien = $idBien";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "Note moyenne: " . round($row['moyenne'], 1) . " / 5";
    }
    

?>