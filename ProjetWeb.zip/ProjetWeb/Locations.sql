CREATE TABLE Locations (
    idLocation INT PRIMARY KEY AUTO_INCREMENT,
    idBien INT,
    mailLoueur VARCHAR(255),
    dateDebut DATE,
    dateFin DATE,
    avis TEXT,
    FOREIGN KEY (idBien) REFERENCES Biens(idBien),
    FOREIGN KEY (mailLoueur) REFERENCES Utilisateurs(mail)
);
INSERT INTO Locations (idBien, mailLoueur, dateDebut, dateFin, avis) VALUES
(1, 'user6@example.com', '2023-07-01', '2023-07-07', 'Très confortable et bien situé.'),
(2, 'user7@example.com', '2023-08-15', '2023-08-22', 'Superbe appartement en centre ville.'),
(3, 'user8@example.com', '2023-09-10', '2023-09-15', 'Agréable séjour, hôte sympathique.'),
(4, 'user9@example.com', '2023-06-05', '2023-06-12', 'Parfait pour un court séjour.'),
(5, 'user10@example.com', '2023-07-20', '2023-07-25', 'Bien équipé et propre.'),
(6, 'user1@example.com', '2023-08-01', '2023-08-08', 'Vue magnifique, très recommandé.'),
(7, 'user2@example.com', '2023-09-18', '2023-09-25', 'Confortable mais un peu bruyant.'),
(8, 'user3@example.com', '2023-07-11', '2023-07-18', 'Excellent rapport qualité-prix.'),
(9, 'user4@example.com', '2023-10-01', '2023-10-07', 'Charmant, bien situé.'),
(10, 'user5@example.com', '2023-06-15', '2023-10-22', 'Idéal pour un séjour familial.');
