<?php
include 'connexion.php';

$idBien = $_POST['idBien'];
$rating = $_POST['rating'];

$sql = "INSERT INTO Avis (idBien, note) VALUES ($idBien, $rating)";
if ($conn->query($sql) === TRUE) {
    echo "Note enregistrée avec succès.";
} else {
    echo "Erreur lors de l'enregistrement de la note: " . $conn->error;
}

$conn->close();
?>
