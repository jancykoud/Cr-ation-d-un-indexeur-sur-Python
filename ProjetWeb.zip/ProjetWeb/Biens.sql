CREATE TABLE Biens (
    idBien INT PRIMARY KEY AUTO_INCREMENT,
    mailProprio VARCHAR(255),
    commune VARCHAR(100),
    rue VARCHAR(100),
    cp VARCHAR(5),
    nbCouchages INT,
    nbChambres INT,
    distance INT,
    prix DECIMAL(10, 2),
    FOREIGN KEY (mailProprio) REFERENCES Utilisateurs(mail)
);

INSERT INTO Biens (mailProprio, commune, rue, cp, nbCouchages, nbChambres, distance, prix) VALUES
('user1@example.com', 'Paris', 'Rue de Rivoli', '75001', 2, 1, 0, 75.00),
('user2@example.com', 'Lyon', 'Rue de la République', '69001', 4, 2, 5, 60.00),
('user3@example.com', 'Marseille', 'La Canebière', '13001', 3, 1, 3, 50.00),
('user4@example.com', 'Bordeaux', 'Cours de l'Intendance', '33000', 5, 3, 2, 85.00),
('user5@example.com', 'Toulouse', 'Allées Jean Jaurès', '31000', 2, 1, 4, 45.00),
('user6@example.com', 'Nice', 'Promenade des Anglais', '06000', 3, 2, 0, 70.00),
('user7@example.com', 'Nantes', 'Place Royale', '44000', 4, 2, 6, 55.00),
('user8@example.com', 'Strasbourg', 'Place Kléber', '67000', 2, 1, 1, 65.00),
('user9@example.com', 'Montpellier', 'Place de la Comédie', '34000', 3, 1, 5, 60.00),
('user10@example.com', 'Lille', 'Place du Général de Gaulle', '59000', 4, 3, 2, 75.00);